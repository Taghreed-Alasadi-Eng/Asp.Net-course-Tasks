﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Restuarant_Reservation.Models
{
    public class BookingRepository
    {
        private static List<Bookings> books = new List<Bookings>();

        public static IEnumerable<Bookings> Books
        {
            get
            {
                return books;
            }
        }

        public static void AddBooks(Bookings book)
        {
            books.Add(book);
        }

    }
}
