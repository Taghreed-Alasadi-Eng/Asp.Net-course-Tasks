﻿using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Restuarant_Reservation.Models
{
    public class Bookings
    {
        [Required(ErrorMessage = "Please enter your name ")]
        public string CustomerName { get; set; }

        [Required(ErrorMessage = "Please enter your phone number ")]
        public int Phone { get; set; }

        [Required(ErrorMessage = "Please enter number of guests ")]
        public int NumberOfGuests { get; set; }

        [Required(ErrorMessage = "Please enter your name ")]
        public Menu Menu { get; set; }

        [Required(ErrorMessage = "Select one of the options ")]
        public bool? HasDrinks { get; set; }

        [Required(ErrorMessage = "Select one of the options ")]
        public bool? HasDesserts { get; set; }
        public double Discount { get; set; }

        public double Total { get; set; }

    }

}
