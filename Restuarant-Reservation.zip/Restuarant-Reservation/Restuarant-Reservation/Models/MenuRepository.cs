﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Restuarant_Reservation.Models
{

    public class MenuRepository
    {
        private static List<Menu> GetMenu = new List<Menu>()
        {
          new Menu
          {
              MealId =1 ,
              NameOfMeal = "Chicken Salad",
              Price = 12,
              Description ="A very delisious meal"

          },
          new Menu
          {
              MealId = 2,
              NameOfMeal = "Fried Rice",
              Price = 14,
              Description ="A very healthy American meal"
          },
            new Menu
          {
              MealId = 3,
              NameOfMeal = "Pasta",
              Price = 13,
              Description ="A very healthy Italian meal"
          }, 
            new Menu
          {
              MealId = 4,
              NameOfMeal = "Yogort Salad",
              Price = 10,
              Description ="Full of vatamins and help lossing weight"
          },  
            new Menu
          {
              MealId = 5,
              NameOfMeal = "Baked Beef",
              Price = 16,
              Description ="A very soucy meal with special flavors"
          }
        };

        public static IEnumerable<Menu> Meals
        {
            get
            {
                return GetMenu;
            }
        }

        public static void AddMenu(Menu menu)
        {
            GetMenu.Add(menu);
        }
    }
}
