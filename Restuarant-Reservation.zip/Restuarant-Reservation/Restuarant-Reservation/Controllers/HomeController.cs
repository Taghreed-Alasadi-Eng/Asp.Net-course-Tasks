﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Logging;
using Restuarant_Reservation.Models;

namespace Restuarant_Reservation.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View("Index");
        }
        /*
        public ViewResult Menu(Menu menu) //localhost:234/home/menu
        {
            //
            ViewBag.menu = MenuRepository.AddMenu(menu);
            return View("Menu", menu);
        }
    
    */
        public ViewResult About()
        {
            return View("About");
        }


        public ViewResult Contact()
         {
                return View("Contact");
         }


        [HttpGet]
        public ViewResult BookIngForm()
        {
            ViewBag.Menu = MenuRepository.Meals;
            return View();
        }

        [HttpPost]
        public ViewResult BookingForm(Bookings book)
        {
           
                //Find Meal
                ViewBag.Menu = MenuRepository.Meals;
                var quantity = book.Menu.Quantity;
                var menu = MenuRepository.Meals.FirstOrDefault(m => m.MealId == book.Menu.MealId);
                book.Menu = menu;
                book.Menu.Quantity = quantity;
                book.Menu = menu;


            if (ModelState.IsValid)
            {
                BookingRepository.AddBooks(book);
                return View("Thanks", book);
            }
            else
            {
                //Error returning 
                return View();
            }
            
        }

        //It uses a default view
        public ViewResult ListMenu()
        {
            return View(MenuRepository.Meals);
        }

    }
}
